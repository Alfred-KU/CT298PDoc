
import numpy as np
import pandas as pd
from statsmodels.stats.outliers_influence import variance_inflation_factor


def calculate_vif(df):
    """Calculate Variance Inflation Factor (VIF) for a dataframe."""
    # Ensure there are no NaNs or infinite values before VIF
    df_clean = df.dropna()
    vif_data = pd.DataFrame()
    vif_data["Feature"] = df_clean.columns

    # Loop through each column to calculate its VIF against the others
    vif_data["VIF"] = [
        variance_inflation_factor(df_clean.values, i)
        for i in range(df_clean.shape[1])
    ]
    return vif_data


def auto_drop_high_vif(df, threshold=5.0):
    """Iteratively drop features with VIF higher than the threshold."""
    df_working = df.dropna().copy()
    while True:
        vif_df = calculate_vif(df_working)
        max_vif = vif_df["VIF"].max()

        if max_vif > threshold:
            # Identify the feature with the highest VIF
            feature_to_drop = vif_df.sort_values(
                by="VIF", ascending=False
            ).iloc[0]["Feature"]
            print(f"Dropping '{feature_to_drop}' (VIF: {max_vif:.2f})")
            df_working = df_working.drop(columns=[feature_to_drop])
        else:
            break
    return df_working


# ==========================================
# 1. GENERATE DUMMY MARKET DATA (Collinear)
# ==========================================
np.random.seed(42)
dates = pd.date_range(start="2025-01-01", periods=100, freq="D")

# Simulate a random walk price path
close_prices = 100 + np.random.normal(0, 1.5, size=100).cumsum()

df = pd.DataFrame({"Close": close_prices}, index=dates)
df["SMA20"] = df["Close"].rolling(window=20).mean()
df["SMA50"] = df["Close"].rolling(window=50).mean()

# Drop rows where SMAs are NaN (due to rolling windows)
df_raw = df.dropna()

print("--- Original Raw Features Correlation ---")
print(df_raw.corr().round(2))

print("\n--- Original Raw Features VIF ---")
print(calculate_vif(df_raw).round(2))


# ==========================================
# METHOD 1: FEATURE TRANSFORMATION (Best Practice)
# ==========================================
print("\n" + "=" * 50)
print("METHOD 1: Transforming into Relative Metrics")
print("=" * 50)

df_transformed = pd.DataFrame(index=df_raw.index)

# Transform absolute values into percentage differences and returns
df_transformed["Daily_Return"] = df_raw["Close"].pct_change()
df_transformed["Dist_to_SMA20"] = (df_raw["Close"] - df_raw["SMA20"]) / df_raw[
    "SMA20"
]
df_transformed["SMA_Spread"] = (df_raw["SMA20"] - df_raw["SMA50"]) / df_raw[
    "SMA50"
]

# Drop the first row which becomes NaN after pct_change
df_transformed = df_transformed.dropna()

print("\n--- Transformed Features Correlation ---")
print(df_transformed.corr().round(2))

print("\n--- Transformed Features VIF ---")
print(calculate_vif(df_transformed).round(2))


# ==========================================
# METHOD 2: ITERATIVE VIF SELECTION (Drop Approach)
# ==========================================
print("\n" + "=" * 50)
print("METHOD 2: Iteratively Dropping High VIF Features")
print("=" * 50)

df_vif_cleansed = auto_drop_high_vif(df_raw, threshold=5.0)

print("\n--- Remaining Features After VIF Drops ---")
print(df_vif_cleansed.columns.tolist())
