import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

# ==========================================
# 1. SETUP SIMULATED DATA & TARGET
# ==========================================
np.random.seed(42)
dates = pd.date_range(start="2025-01-01", periods=200, freq="D")
close_prices = 100 + np.random.normal(0, 1.5, size=200).cumsum()

df = pd.DataFrame({"Close": close_prices}, index=dates)
df["SMA20"] = df["Close"].rolling(window=20).mean()
df["SMA50"] = df["Close"].rolling(window=50).mean()

# Define a Target: Let's predict the Close Price 1 day in the future
df["Target_Next_Day_Close"] = df["Close"].shift(-1)
df = df.dropna()

# Features (Highly Collinear) and Target
X = df[["Close", "SMA20", "SMA50"]]
y = df["Target_Next_Day_Close"]

# Split into Train and Test sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)  # False for time-series data

# ==========================================
# 2. BUILDING THE PCA PIPELINE
# ==========================================
# PCA is highly sensitive to variances, so scaling data FIRST is mandatory.
# We retain 2 components out of 3 features to compress the redundant data.
pca_pipeline = Pipeline(
    [
        ("scaler", StandardScaler()),
        ("pca", PCA(n_components=2)),
        ("regressor", LinearRegression()),
    ]
)

# Train the entire pipeline
pca_pipeline.fit(X_train, y_train)

# Evaluate the model
train_score = pca_pipeline.score(X_train, y_train)
test_score = pca_pipeline.score(X_test, y_test)

print(f"Pipeline Train R^2 Score: {train_score:.4f}")
print(f"Pipeline Test R^2 Score:  {test_score:.4f}")

# ==========================================
# 3. ANALYZING THE PCA COMPONENTS
# ==========================================
# Let's peek inside the pipeline to see how PCA removed the multicollinearity
pca_step = pca_pipeline.named_steps["pca"]
explained_variance = pca_step.explained_variance_ratio_

print("\n--- PCA Breakdown ---")
print(
    f"Component 1 captures: {explained_variance[0]*100:.2f}% of data variance"
)
print(
    f"Component 2 captures: {explained_variance[1]*100:.2f}% of data variance"
)
print(f"Total variance retained: {sum(explained_variance)*100:.2f}%")

# Verify that PCA components are perfectly uncorrelated (Correlation matrix = 0)
X_train_scaled = pca_pipeline.named_steps["scaler"].transform(X_train)
X_train_pca = pca_step.transform(X_train_scaled)
pca_corr = pd.DataFrame(X_train_pca).corr().round(2)

print("\n--- Correlation Matrix of the PCA Components (Perfectly Uncorrelated) ---")
print(pca_corr)
